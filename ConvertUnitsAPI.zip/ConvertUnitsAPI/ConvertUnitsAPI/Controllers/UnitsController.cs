﻿using Microsoft.AspNetCore.Mvc;
using Units.Core.Entity.Units;
using Units.Core.Interface.Units;

namespace UnitsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UnitsController : ControllerBase
    {
        private readonly IUnits _Units;
        public UnitsController(IUnits iUnits)
        {
            _Units = iUnits;
        }
        //get Final Value of Converted Units from DB
        [HttpPost("units.Conversion")]
        public async Task<IActionResult> ConvertUnits([FromBody] UnitsDetails _unitDetails)
        {
            List<UnitsDetails> unitsDetails = new List<UnitsDetails>();
            unitsDetails = _Units.ConvertUnits(_unitDetails);
            return Ok(unitsDetails);
        }
    }
}
