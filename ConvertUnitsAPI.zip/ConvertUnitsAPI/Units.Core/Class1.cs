﻿namespace Units.Core
{
    public class Class1
    {

    }
}