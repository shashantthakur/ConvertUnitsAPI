﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Units.Core.Entity.Units
{
    public class UnitsDetails
    {
        public string? FromUnit { get; set; }
        public string? ToUnit { get; set; }
        public string? ConvTimes { get; set; }
        public string? TotalConvUnits { get; set; }
    }
}
