﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Units.Core.Entity.Units;

namespace Units.Core.Interface.Units
{
    public interface IUnits
    {
        List<UnitsDetails> ConvertUnits(UnitsDetails unitsDetails);
    }
}
