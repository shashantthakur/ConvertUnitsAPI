﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Units.Core.Entity.Units;
using Units.Core.Interface.Units;
using Units.Infrastructure.Class;

namespace Units.Infrastructure.Service
{
    public class UnitsService : IUnits
    {
        public List<UnitsDetails> ConvertUnits(UnitsDetails unitsDetails)
        {
            //Passing details of FromUnit, ToUnit to database, doing conversion in sp and return the final converted units 
            return CommonResource.ToCollection<UnitsDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetUnitsConvDetails", unitsDetails.FromUnit, unitsDetails.ToUnit).Tables[0]);
        }
    }
}
