﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace Units.Infrastructure.Class
{
    public class Common
    {
        public Common(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            CommonResource.ConString = configuration["DBConnection:ConString"];
        }
    }
    public static class CommonResource
    {
        public static string ConString { get; set; }

        public static List<T> ToCollection<T>(this DataTable dt)
        {
            try
            {
                if (dt.Rows.Count > 0)
                {
                    string js = Newtonsoft.Json.JsonConvert.SerializeObject(dt);
                    List<T> lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(js);
                    return lst;
                }
                else
                {
                    List<T> lst = new System.Collections.Generic.List<T>();
                    return lst;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
