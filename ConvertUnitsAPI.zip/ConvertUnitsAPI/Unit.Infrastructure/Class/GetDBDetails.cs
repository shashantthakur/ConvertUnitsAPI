﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Text;

namespace Units.Infrastructure.Class
{
    public static class DbContext
    {
        private static readonly DatabaseProviderFactory databaseProviderFactory = new DatabaseProviderFactory();
        public static Database DbUser => new SqlDatabase(CommonResource.ConString);
    }
}
