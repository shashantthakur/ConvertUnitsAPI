﻿namespace Unit.Infrastructure
{
    public class Class1
    {

    }
}